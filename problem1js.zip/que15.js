let num =45;
 if ((num<100)&&(num>90)){
   console.log("gread A");
 }
else if((num<89)&& (num>80 )){
  console.log("gread B");
  
}
else if ((num<79)&& ( num)