let item =110;

if(item==110){
  console.log("discount Applied");
}
else{
  cosole.log("not applied");
}
