let a=3 
let b = 4
console.log(a%b);
