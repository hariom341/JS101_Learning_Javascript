let age =10;

if (age>18){
  console.log("eligible for vote in election");
  
}
else {
   console.log("not eligible for vote in election ")
}
