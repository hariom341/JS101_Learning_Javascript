let name = " lusi ";
console.log(name );
let fathername;
fathername ="hi ";
console.log(fathername);
 