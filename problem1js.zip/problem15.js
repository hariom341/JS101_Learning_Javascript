let a =3 ;
 let b = 5 ;
 console.log(a+b);