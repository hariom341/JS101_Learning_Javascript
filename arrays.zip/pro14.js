 let  array = [ -1, -3333, -666,4,5,7,75];
 let min = +initi3