let arr = ["masai","mschool", "web"];

//how many characters 

let count=

  