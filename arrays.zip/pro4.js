// if we want to remove alway last element;


let class_room= [ "luffy",11,2,3,4,5,6,7,"name " , "lala"];
 class_room.pop();
class_room.pop();


 console.log(class_room);
