let  array = [1,2,3,4,5];
///[5,4,3,2,1]

let b =[];

 for( let i=array.length -1;i >=0;i--){

   b.push(array[i]);
 }
console.log(b);
