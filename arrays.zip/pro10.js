//small to capital;


let small =[ "a", "b", "c"];

let capital_case = [ "A" , "B" , "C" ];
let character = "b";




for (let i= 0; i<small.length; i++){
  if (small[i]==character) {
    character = capital_case[i];
  }
}console.log(character);