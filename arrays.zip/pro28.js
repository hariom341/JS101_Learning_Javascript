let arr= [ 10,7,9,8,10]
//6,8
count=0;

for ( let i =0; i<arr.length; i++){
  if (arr[i]<arr[i-1] && arr[i] < arr[i+ 1])
  {
    count ++;
    
    
    
  }

  
}
      console.log(count);
