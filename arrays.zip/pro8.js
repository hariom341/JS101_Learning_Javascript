let a = [ 1,-2,-5, 5,6,7,8 ];
for (let i=0; i<a.length; i++){

  if (a[i]<0){
    a[i]=0;
  }
}
 console.log(a);