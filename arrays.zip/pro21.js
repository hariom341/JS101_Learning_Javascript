let a= [ 1,2,3];

a.push(7,8,9);
console.log(a);
