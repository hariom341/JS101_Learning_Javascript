let cha1= ["a", "b", "c"];

let cha2= ["A","B","C"];

let cha= "a"; 

for(let i=0; i<cha1.length;i++)
{
  if(cha1[i]== cha){
    
    cha= cha2[i];
    
  }
}

console.log(cha);

