let  arr = [a,d,g,i,o];
bag = "";

 for ( let i = 0; i<arr.length; i++){
   if (arr[i]=="a"|| arr[i]=="e"|| arr[i]=="i"|| arr[i]=="o"|| arr[i]=="u"){
    bag= bag+arr[i];
       }
 }
if (bag==""){
  console.log("not")
  
}
else {
  console.log("YEs")
}

