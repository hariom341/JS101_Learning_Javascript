//push  it is use  to add  element ;



let class_room= [ "luffy",11,2,3,4,5,6,7,"name " , "lala"];
let father_name = "luffy";

class_room.push("anna");
class_room.push(true);
class_room.push(1);



for (i=0; i<class_room.length; i++){
  console.log(class_room[i]);
}
 console.log (class_room.length);