let char= ["a","s","d","f","g","h"];
let count=0;
for ( let i =0; i<char.length;i++){
  count = count + 1;
}
console.log(count);