let class_room= [ "luffy",11,2,3,4,5,6,7,"name " , "lala"];
for (i=0; i<class_room.length; i++){
  console.log(class_room[i]);
}