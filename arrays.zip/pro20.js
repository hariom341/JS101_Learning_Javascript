//let a =[1,2,3,4,5,6];

//for reversing;



let  str = "masai";
let b ="";
for ( let i= str.length -1; i>=0;i--){
b= b+str[i];
   
 }    console.log(b);

