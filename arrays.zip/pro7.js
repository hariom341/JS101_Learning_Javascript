let  class_room = [ "ram " , "kaM " , " shyam ", " mohan"];




let i = 0 ;
 for (let i = 0; i<class_room.length; i++){

console.log(i+1,class_room[i]) ;
 }