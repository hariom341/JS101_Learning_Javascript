let a ="masai school";

for( let i= 0; i<a.length;i++){
console.log(a[i]);
  
}

