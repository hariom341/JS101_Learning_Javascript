let class_room =[ "ram "," mohan ","joro ","toro","uoko"];



//  for replace this 
 class_room[0]= " anil";

class_room[3] = " baba";

 console.log(class_room);
