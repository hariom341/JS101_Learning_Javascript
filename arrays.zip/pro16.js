let  a =[1,2,3,4];

let b="luffy";

a[0]= "hello";

 console.log(a)