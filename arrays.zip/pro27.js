let arr =[ 2,4,6,8,9,10,11];
for ( let i=0; i<arr.length;i++){
  if ( arr[i]%2==1){
    console.log(arr[i]);
    
  }
}