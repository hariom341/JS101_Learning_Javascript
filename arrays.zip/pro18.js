let  arr =[ "lufu ", "joro" ];

console.log(arr[0]);
console.log(arr[1][0]);
