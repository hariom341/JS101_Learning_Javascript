let a =[ 1,2,3,4,5,6];
//even and odd count 
let count_e=0
  let count_o=0;


 for ( let i =0; i< a.length;i++){

   if(a[i]%2==0){
     count_e = count_e +1;
     
     
   }
   else {
count_o= count_o+1;
     
   }
 }
console.log("even", count_e, "odd" , count_o);
