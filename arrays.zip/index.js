//array


let class_room  = [ "luffy" , 1, 2, 3 , true , false ];
console.log(class_room[0]);
 console.log(class_room[1]);
console.log (class_room[4]);

console.log(class_room[5]);