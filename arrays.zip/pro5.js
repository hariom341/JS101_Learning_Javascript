//spread operator 

let class_room= [ "luffy",11,2,3,4,5,6,7,"name " , "lala"];

let class_room_2= [ " 1",2,3,4,5,6,7,8];

 let class_room_3= [...class_room,...class_room_2 ];

console.log(class_room_3);