let  arr = ["hi ","bye", "ram", "shyam"];
let count = 0;

for (let i = 0; i < arr.length; i++){
  count =  count + arr[i].length;
}

console.log( count);