let class_room= ["ram " ,1,2,3,4,56,7];

console.log(class_room.length);